# First test build

Goal: get the app onto one phone and run the checklist at the bottom. Nothing here has been run on a real phone yet, so expect to fix small things.

Choose **one** path.

## Path A: on a computer (Windows, Mac or Linux)

1. Install **Node.js 22** (nodejs.org) and **Android Studio** (developer.android.com/studio). Open Android Studio once so it downloads the Android SDK.
2. Set `ANDROID_HOME` to the SDK folder (Android Studio shows it under Settings > Android SDK).
3. In this folder:
   ```bash
   npm install
   npm run doctor -- --android      # fix anything it marks FAIL
   npm run build:www
   npx cap add android              # once
   npm run icons                    # app icon and splash screen
   npx cap sync android
   npx cap open android             # opens Android Studio
   ```
4. In Android Studio: connect a phone with USB debugging on and press **Run**, or choose **Build > Build APK(s)** and send `app-debug.apk` to the phone.

First time takes 20 to 40 minutes (downloads). Later builds take a minute or two.

## Path B: no Android Studio (GitHub builds it for you)

1. Make a free account on github.com and create a **private** repository.
2. Upload **all** the files of this folder, keeping the folders (`app/`, `assets/`, `scripts/`, `src/`, `.github/workflows/`). Uploading folders is much easier from a computer than from a phone.
3. Optional: if you already run the cloud service, add a repository secret named `CLOUD_URL` with its `https://` address (Settings > Secrets and variables > Actions).
4. Open the **Actions** tab, choose **Android debug build**, press **Run workflow**. It takes about 8 to 15 minutes.
5. When it turns green, open the run and download **golden-gates-debug-apk**. Unzip it to get `app-debug.apk`.
6. On the phone: open the APK. Android asks to allow installing from this source: allow it. If Play Protect warns about an unknown app, choose *Install anyway* (it is a test version made by you).

If the run turns red, open the failed step and send me the last 30 lines of its log.

## iPhone

Needs a **Mac with Xcode** and an Apple developer account. Run `npm run doctor -- --ios`, `npx cap add ios`, `npm run icons`, `npx cap sync ios`, `npx cap open ios`, then run it on a connected iPhone from Xcode. A free Apple ID can install on your own phone for 7 days. Do the Android test first.

## Phone requirements

The app uses web features from about **Chrome 87** (2021). On Android that means the phone's *Android System WebView* must be up to date. Phones on Android 7 or newer that receive Play Store updates are fine. Very old phones that never update may show a broken layout.

## Checklist for the first run

Tick each one on the phone. Write down anything that is wrong.

1. The app opens and shows the lock screen with a phone code.
2. Make a code with the generator, enter it, and the app unlocks.
3. Create an invoice, record a payment, open the receipt. Fonts look right.
4. **Send PDF** opens the phone's share sheet and WhatsApp receives a readable PDF.
5. **Download PDF** and an export (Profile > Export and reports > ZIP) open the share sheet. Save the ZIP to Files and open it.
6. **Back up my data** saves a file. **Erase all data**, then **Restore from backup** brings everything back.
7. Switch on **airplane mode** and repeat steps 3 and 4: everything must still work.
8. Close the app fully and open it again: data and activation are still there. Profile > Backup > *Automatic backups* shows today's copy.
9. Change language to French, and try dark mode.
10. Press the phone's back button on each tab: note what happens.
11. Try it on a small screen and on a large one.
12. (Only if the cloud service is running) create a cloud account, back up, then restore on a second phone.

## Common problems

| Message or symptom | What to do |
|---|---|
| `SDK location not found` | Set `ANDROID_HOME`, or create `android/local.properties` with `sdk.dir=/path/to/Android/sdk` |
| `Unsupported class file major version` or Java errors | Use JDK 17 |
| `npx cap sync` says `www` is missing | Run `npm run build:www` first |
| White screen on the phone | Run `npm run build:www` and `npx cap sync` again, and check `www/index.html` exists |
| `doctor` says the app file "looks already converted" | You copied `www/index.html` over `app/index.html`. Put the original web file back |
| Icons are the default Capacitor ones | Run `npm run icons` before `npx cap sync` |
