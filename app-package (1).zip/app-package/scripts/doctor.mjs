// Checks that this computer (or the build server) is ready for the first build.
//   npm run doctor            checks the project
//   npm run doctor -- --android   also checks Java and the Android tools
//   npm run doctor -- --ios       also checks Xcode and CocoaPods (Mac only)
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const results = [];
const add = (level, name, ok, fix) => results.push({ level, name, ok, fix });
const run = (cmd, a) => { const r = spawnSync(cmd, a, { encoding: 'utf8' }); return r.error ? null : (r.stdout || '') + (r.stderr || ''); };
const has = (...p) => fs.existsSync(path.join(root, ...p));

// ----- the project
const nodeMajor = Number(process.versions.node.split('.')[0]);
add('must', `Node.js ${process.versions.node} (needs 18 or newer)`, nodeMajor >= 18, 'Install Node.js 22 from nodejs.org.');
const installed = has('node_modules', '@capacitor', 'core') && has('node_modules', 'jspdf') && has('node_modules', '@fontsource', 'dm-sans');
add('must', 'Packages are installed (npm install)', installed, 'Run: npm install');
let html = '';
try { html = fs.readFileSync(path.join(root, 'app', 'index.html'), 'utf8'); } catch { /* reported below */ }
add('must', 'app/index.html is present', html.length > 50000, 'Copy the latest app file to app/index.html.');
add('must', 'app/index.html still loads fonts from Google Fonts (the build replaces them)', /fonts\.googleapis\.com/.test(html), 'app/index.html looks already converted. Use the original file.');
add('must', 'app/index.html still loads the PDF tool from cdnjs (the build replaces it)', /cdnjs\.cloudflare\.com\/ajax\/libs\/jspdf/.test(html), 'app/index.html looks already converted. Use the original file.');
add('must', 'The privacy sentence the build rewrites is present', html.includes('For now, fonts are loaded from Google Fonts and the PDF tool from cdnjs'), 'Use the latest app/index.html.');
let cfg = null;
try { cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8')); } catch { /* reported below */ }
add('must', 'capacitor.config.json is valid', !!cfg && cfg.webDir === 'www', 'Fix capacitor.config.json (webDir must be "www").');
add('must', 'appId looks valid (like com.company.app)', !!cfg && /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(cfg.appId || ''), 'Edit appId in capacitor.config.json.');
add('should', 'App icon and splash images are in assets/', has('assets', 'icon-only.png') && has('assets', 'splash.png'), 'Add assets/icon-only.png (1024x1024) and assets/splash.png (2732x2732).');
const cloud = process.env.CLOUD_URL || '';
add('should', cloud ? `CLOUD_URL is ${cloud}` : 'CLOUD_URL is not set (the cloud account will be switched off)', !cloud || /^https:\/\//.test(cloud), 'CLOUD_URL must start with https://');

// ----- Android
if (args.includes('--android')) {
  const jv = run('java', ['-version']);
  const major = jv ? Number((/version "(\d+)/.exec(jv) || [])[1]) : 0;
  add('must', `Java ${major || 'not found'} (needs 17)`, major >= 17, 'Install JDK 17 (Android Studio includes one) and set JAVA_HOME.');
  const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || '';
  add('must', `Android SDK ${sdk ? 'at ' + sdk : 'not set'}`, !!sdk && fs.existsSync(sdk), 'Install Android Studio, then set ANDROID_HOME to its SDK folder.');
}
// ----- iPhone
if (args.includes('--ios')) {
  const mac = process.platform === 'darwin';
  add('must', 'This is a Mac (iPhone apps can only be built on a Mac)', mac, 'Use a Mac with Xcode.');
  if (mac) {
    add('must', 'Xcode is installed', !!run('xcodebuild', ['-version']), 'Install Xcode from the App Store.');
    add('must', 'CocoaPods is installed', !!run('pod', ['--version']), 'Run: sudo gem install cocoapods');
  }
}

let bad = 0, warn = 0;
for (const r of results) {
  const mark = r.ok ? 'OK  ' : r.level === 'must' ? 'FAIL' : 'WARN';
  console.log(`${mark}  ${r.name}${r.ok ? '' : '\n        -> ' + r.fix}`);
  if (!r.ok) r.level === 'must' ? bad++ : warn++;
}
console.log(bad ? `\n${bad} problem(s) to fix before building.` : `\nReady to build${warn ? ` (${warn} warning(s))` : ''}.`);
process.exit(bad ? 1 : 0);
