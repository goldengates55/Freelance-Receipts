// Builds the www/ folder that Capacitor puts inside the app:
//  - copies app/index.html
//  - replaces Google Fonts and the cdnjs PDF library with copies bundled in the app (works offline)
//  - adds the native file-saving bridge
// Run with:  npm run build:www
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const www = path.join(root, 'www');
const nm = (...p) => path.join(root, 'node_modules', ...p);
const fail = (m) => { console.error('ERROR: ' + m); process.exit(1); };

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(path.join(www, 'fonts'), { recursive: true });
let html = fs.readFileSync(path.join(root, 'app', 'index.html'), 'utf8');

// 1. fonts bundled from the @fontsource packages
const FONTS = [
  { pkg: 'dm-sans', family: 'DM Sans', weights: [400, 500, 700] },
  { pkg: 'bricolage-grotesque', family: 'Bricolage Grotesque', weights: [500, 700] },
  { pkg: 'ibm-plex-mono', family: 'IBM Plex Mono', weights: [400, 500] },
  { pkg: 'lora', family: 'Lora', weights: [400, 600, 700] },
];
const RANGE = {
  'latin': 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD',
  'latin-ext': 'U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF',
};
let css = '';
for (const f of FONTS) {
  for (const w of f.weights) {
    for (const subset of ['latin', 'latin-ext']) {
      const file = `${f.pkg}-${subset}-${w}-normal.woff2`;
      const src = nm('@fontsource', f.pkg, 'files', file);
      if (!fs.existsSync(src)) {
        if (subset === 'latin') fail(`missing font file ${src}. Did you run "npm install"?`);
        continue;
      }
      fs.copyFileSync(src, path.join(www, 'fonts', file));
      css += `@font-face{font-family:'${f.family}';font-style:normal;font-display:swap;font-weight:${w};src:url(fonts/${file}) format('woff2');unicode-range:${RANGE[subset]}}\n`;
    }
  }
}
fs.writeFileSync(path.join(www, 'fonts.css'), css);
const before = html;
html = html.replace(/<link[^>]+fonts\.(googleapis|gstatic)\.com[^>]*>\s*/g, '');
if (html === before) fail('could not find the Google Fonts link in app/index.html');
html = html.replace('</head>', '<link rel="stylesheet" href="fonts.css">\n</head>');

// 2. PDF library bundled instead of loaded from cdnjs
const jspdf = nm('jspdf', 'dist', 'jspdf.umd.min.js');
if (!fs.existsSync(jspdf)) fail('missing ' + jspdf + '. Did you run "npm install"?');
fs.copyFileSync(jspdf, path.join(www, 'jspdf.umd.min.js'));
const cdn = /<script src="https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jspdf\/[^"]+"><\/script>/;
if (!cdn.test(html)) fail('could not find the jsPDF script tag in app/index.html');
html = html.replace(cdn, '<script src="jspdf.umd.min.js"></script>\n<script src="native.js"></script>');

// 2b. cloud account: write the service address into the app (optional)
const cloud = process.env.CLOUD_URL || '';
if (cloud) {
  if (!/^https:\/\//.test(cloud) && !process.env.ALLOW_HTTP) fail('CLOUD_URL must start with https:// (set ALLOW_HTTP=1 only for local tests)');
  html = html.replace('<script src="native.js"></script>', '<script src="native.js"></script>\n<script>window.CLOUD_URL=' + JSON.stringify(cloud) + '</script>');
  console.log('Cloud account switched on: ' + cloud);
} else {
  console.log('Note: CLOUD_URL is not set, so the cloud account is switched off in this build.');
}

// 3. privacy text now matches what the app really does
const swaps = [
  ['For now, fonts are loaded from Google Fonts and the PDF tool from cdnjs, so those providers can see your device’s IP address.',
   'Fonts and the PDF tool are built into the app, so the app makes no requests to outside providers for them.'],
  ['Pour l’instant, les polices sont chargées depuis Google Fonts et l’outil PDF depuis cdnjs : ces fournisseurs peuvent donc voir l’adresse IP de votre appareil.',
   'Les polices et l’outil PDF sont intégrés à l’application : elle ne contacte aucun fournisseur externe pour eux.'],
];
for (const [a, b] of swaps) {
  if (!html.includes(a)) fail('privacy sentence not found: ' + a.slice(0, 40));
  html = html.split(a).join(b);
}

// 4. native bridge (file saving and sharing)
if (process.env.SKIP_BUNDLE) {
  fs.writeFileSync(path.join(www, 'native.js'), '/* skipped in test */');
} else {
  execFileSync(process.platform === 'win32' ? 'npx.cmd' : 'npx',
    ['esbuild', path.join(root, 'src', 'native.js'), '--bundle', '--minify', '--format=iife', '--outfile=' + path.join(www, 'native.js')],
    { cwd: root, stdio: 'inherit' });
}

fs.writeFileSync(path.join(www, 'index.html'), html);

// 5. final check: nothing may still point to the internet
const left = html.match(/https?:\/\/(?!wa\.me|www\.w3\.org)[^"'\s)]+/g) || [];
const bad = left.filter((u) => /googleapis|gstatic|cdnjs|jsdelivr|unpkg/.test(u));
if (bad.length) fail('still loading from the internet: ' + bad.join(', '));
console.log(`Done. www/ is ready (${fs.readdirSync(path.join(www, 'fonts')).length} font files, ${(html.length / 1024).toFixed(0)} KB of app code).`);
