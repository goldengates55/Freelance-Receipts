# Golden Gates Freelance Payment System: Android and iPhone app

This folder turns the web version into a real app using Capacitor (one code base, two apps).
The build script was tested offline with stand-in files. **It has not yet been run with the real packages, or on a phone.** Expect to fix small things the first time.

## What you need

| For | You need |
|---|---|
| Both | A computer with Node.js 18 or newer, and an internet connection for the first `npm install` |
| Android | Android Studio (free). A Windows, Mac or Linux computer works |
| iPhone | A Mac with Xcode, and a paid Apple Developer account to put the app on real phones or the App Store |

## Build it

```bash
cd app-package
npm install
npm run build:www      # builds www/: bundles fonts and the PDF tool, adds file saving
npx cap add android    # once
npx cap add ios        # once, on a Mac
npm run android        # builds, syncs and opens Android Studio
npm run ios            # builds, syncs and opens Xcode
```

After any change to `app/index.html`, run `npm run sync` again.
`app/index.html` is a copy of the web version. Replace it with the latest file whenever the web version changes.

## What `npm run build:www` does

1. Copies `app/index.html` to `www/`.
2. Replaces Google Fonts with fonts stored inside the app, and the cdnjs PDF library with a copy inside the app. The app then works with no internet.
3. Updates the privacy sentence so it matches (no outside providers for fonts or PDF).
4. Adds `native.js`, which lets the app save and share files through the phone's share sheet (WhatsApp, email, Save to Files).
5. Stops with an error if anything still points to the internet.

## Before you publish

1. **App name, ID and icon.** Change `appId` in `capacitor.config.json` (it cannot change after you publish). Add a 1024x1024 `assets/icon.png` and run `npx @capacitor/assets generate`.
2. **Test on real phones.** Check: unlock with a code, create an invoice, record a payment, Send PDF to WhatsApp, export a ZIP, back up and restore, French, dark mode, offline (airplane mode), a small phone and a large one.
3. **Android signing.** In Android Studio: Build > Generate Signed Bundle. Keep the key file and passwords safe. If you lose them you cannot update the app.
4. **Privacy policy.** Both stores ask for a web address of a privacy policy. Say that data stays on the device, that nothing is sent to a server, and how to erase it (Profile > Privacy and data).
5. **Store forms.** Google Play "Data safety" and Apple "App Privacy": the app collects no data and shares none.

## Keeping the data safe

Built into this version of the app:

1. **Private copy.** Every change is also written to a file in the app's private storage, with one snapshot per day kept for 7 days. If the phone cleans the app's normal web storage (for example when space runs low) the app restores itself, including the activation and phone code, the next time it starts. Profile > Backup > *Automatic backups* lists the snapshots so a customer can go back to an earlier day. **This does not survive "Clear data" or uninstalling the app**, because the private folder is deleted too. For that, customers need a backup file or the cloud account.
2. **Phone backups.** That private folder is normally included in Android's automatic backup and in iPhone's iCloud backup, so it often comes back on a new phone. This depends on the customer's phone settings. Do not promise it.
3. **Cloud account (optional).** With the cloud service in `../cloud-server` running, customers can sign in (email or phone number) and the app keeps an encrypted copy in the cloud, which they can restore on a new phone. Build with `CLOUD_URL=https://your-service.example.com npm run build:www`. Without it, the cloud card says it is not set up.

If you use the cloud service, add its address to the allowed origins (`CORS_ORIGINS=https://localhost,capacitor://localhost` already covers the Android and iPhone apps).

## Two important risks to check

- **Store payment rules.** Google Play and the Apple App Store both have rules about unlocking paid features. If customers buy activation codes from you outside the store, a store may require the store's own payment system, or may reject the app. Read Google Play's Payments policy and Apple's App Store Review Guideline 3.1 before you rely on this. Many businesses in your region share an Android APK directly (for example on WhatsApp) instead, which avoids the Play Store but needs customers to allow installs from outside the store.
- **Phone data can still be lost in some cases.** See "Keeping the data safe" below. The app now protects against the common ones, but deleting the app on a phone that does not back itself up, or losing the phone, still loses everything that was not backed up.

## Known limits of this first package

- The activation code check, backup and exports are the same as the web version.
- Saving always opens the phone's share sheet (the file is written to the app's cache first). There is no silent "download to Documents".
- There are no push notifications, and no biometric lock yet. Anyone who opens the phone can open the app.
- Updates go through the stores, or by sending a new APK.
