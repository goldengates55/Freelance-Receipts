// Native helpers for the packaged app (Android and iPhone), through Capacitor.
//   saveShare(base64, name, title)  : write a file, then open the phone's share sheet
//   writeData(json) / readData()    : the app's durable copy, in the app's private storage
//   listSnapshots() / readSnapshot(name) : one automatic backup per day, kept for 7 days
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const DIR = 'slip';
const KEEP_DAYS = 7;
const SNAP = /^snapshot-(\d{4}-\d{2}-\d{2})\.json$/;
const today = () => {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
};
const ensureDir = async () => { try { await Filesystem.mkdir({ path: DIR, directory: Directory.Data, recursive: true }); } catch (e) { /* already there */ } };

window.NativeBridge = {
  async saveShare(base64, name, title) {
    const written = await Filesystem.writeFile({ path: name, data: base64, directory: Directory.Cache });
    try {
      await Share.share({ title, dialogTitle: title, url: written.uri });
    } catch (e) {
      if (/cancel/i.test(String((e && e.message) || e))) return 'cancel';
      throw e;
    }
    return 'ok';
  },

  async writeData(json) {
    await ensureDir();
    await Filesystem.writeFile({ path: DIR + '/data.json', data: json, directory: Directory.Data, encoding: Encoding.UTF8 });
    // today's snapshot (overwritten during the day), then remove the ones older than KEEP_DAYS
    await Filesystem.writeFile({ path: DIR + '/snapshot-' + today() + '.json', data: json, directory: Directory.Data, encoding: Encoding.UTF8 });
    const { files } = await Filesystem.readdir({ path: DIR, directory: Directory.Data });
    const snaps = files.map((f) => f.name).filter((n) => SNAP.test(n)).sort();
    for (const old of snaps.slice(0, Math.max(0, snaps.length - KEEP_DAYS))) {
      try { await Filesystem.deleteFile({ path: DIR + '/' + old, directory: Directory.Data }); } catch (e) { /* ignore */ }
    }
  },

  async readData() {
    try {
      const r = await Filesystem.readFile({ path: DIR + '/data.json', directory: Directory.Data, encoding: Encoding.UTF8 });
      return typeof r.data === 'string' ? r.data : null;
    } catch (e) { return null; }
  },

  async listSnapshots() {
    try {
      const { files } = await Filesystem.readdir({ path: DIR, directory: Directory.Data });
      return files
        .filter((f) => SNAP.test(f.name))
        .map((f) => ({ name: f.name, date: f.name.match(SNAP)[1], size: f.size || 0 }))
        .sort((a, b) => b.name.localeCompare(a.name));
    } catch (e) { return []; }
  },

  async readSnapshot(name) {
    if (!SNAP.test(name)) throw new Error('bad snapshot name');
    const r = await Filesystem.readFile({ path: DIR + '/' + name, directory: Directory.Data, encoding: Encoding.UTF8 });
    return r.data;
  },
};
